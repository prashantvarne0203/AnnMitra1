// js/cryptoUtils.js
// NOTE: This is a static, serverless demo. Passwords are hashed with SHA-256
// via the browser's built-in SubtleCrypto (no plaintext storage), but this is
// NOT equivalent to a real server-side auth system (no salt rotation, no rate
// limiting, hash is visible to anyone inspecting localStorage). Never reuse a
// real/important password when trying this demo.

const CryptoUtils = (() => {
  async function hashPassword(password) {
    const enc = new TextEncoder().encode(password);
    const digest = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  async function verifyPassword(password, hash) {
    const h = await hashPassword(password);
    return h === hash;
  }

  function uuid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    // Fallback for older browsers
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  return { hashPassword, verifyPassword, uuid };
})();
