// js/store.js
// A browser-only datastore using localStorage, with the same shape/API as the
// original server/db.js. This is what makes the site work with zero backend —
// but it also means data lives only in the visitor's own browser, not shared
// between different people or devices.

const Store = (() => {
  const KEY = "resq_static_store_v1";

  const DEFAULT_STATE = {
    users: [],
    sellers: [],
    listings: [],
    orders: [],
    clubs: []
  };

  function readAll() {
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      writeAll(DEFAULT_STATE);
      return { ...DEFAULT_STATE };
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return { ...DEFAULT_STATE };
    }
  }

  function writeAll(state) {
    localStorage.setItem(KEY, JSON.stringify(state));
  }

  function all(collection) {
    const state = readAll();
    return state[collection] || [];
  }

  function find(collection, predicate) {
    return all(collection).find(predicate);
  }

  function filter(collection, predicate) {
    return all(collection).filter(predicate);
  }

  function insert(collection, record) {
    const state = readAll();
    if (!state[collection]) state[collection] = [];
    state[collection].push(record);
    writeAll(state);
    return record;
  }

  function update(collection, id, patch) {
    const state = readAll();
    const list = state[collection] || [];
    const idx = list.findIndex((r) => r.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...patch };
    writeAll(state);
    return list[idx];
  }

  function remove(collection, id) {
    const state = readAll();
    const list = state[collection] || [];
    state[collection] = list.filter((r) => r.id !== id);
    writeAll(state);
  }

  function resetAll() {
    writeAll(DEFAULT_STATE);
  }

  return { all, find, filter, insert, update, remove, readAll, writeAll, resetAll };
})();
