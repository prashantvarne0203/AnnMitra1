// js/aiEngine.js
// Rule-based "AI": smart pricing, food/carbon/water savings calc, recipe
// suggestions, demand forecast, badges. Identical logic to the Node version,
// just exposed as a browser global instead of a CommonJS module.

const AI = (() => {
  const CO2_KG_PER_KG_FOOD = 2.5;
  const WATER_L_PER_KG_FOOD = 1000;
  const POINTS_PER_KG = 10;

  function computeImpact(foodKg) {
    const co2SavedKg = +(foodKg * CO2_KG_PER_KG_FOOD).toFixed(2);
    const waterSavedL = +(foodKg * WATER_L_PER_KG_FOOD).toFixed(0);
    const points = Math.round(foodKg * POINTS_PER_KG);
    return { foodKg: +foodKg.toFixed(2), co2SavedKg, waterSavedL, points };
  }

  function suggestDiscount({ hoursToExpiry = 6, demandScore = 0.5, isRaining = false, hourOfDay = new Date().getHours() }) {
    let discount = 50;
    const reasons = [];

    if (hoursToExpiry <= 1) {
      discount = 80;
      reasons.push("Less than 1 hour to pickup deadline — steep discount to guarantee sale");
    } else if (hoursToExpiry <= 3) {
      discount = 70;
      reasons.push("Under 3 hours left — increasing discount to move stock faster");
    } else if (hoursToExpiry <= 6) {
      discount = 60;
      reasons.push("6 hours or less left — moderate urgency discount");
    } else {
      discount = 50;
      reasons.push("Plenty of time left — platform minimum discount applied");
    }

    if (demandScore < 0.3) {
      discount = Math.min(80, discount + 10);
      reasons.push("Low current demand nearby — bumping discount to attract buyers");
    } else if (demandScore > 0.7) {
      discount = Math.max(50, discount - 10);
      reasons.push("High demand nearby — smaller extra discount still needed");
    }

    if (isRaining) {
      discount = Math.min(80, discount + 5);
      reasons.push("Bad weather usually reduces footfall — small extra nudge");
    }

    if (hourOfDay >= 21 || hourOfDay <= 5) {
      discount = Math.min(80, discount + 5);
      reasons.push("Late night / closing hours — extra push to clear stock");
    }

    discount = Math.max(50, Math.min(80, Math.round(discount / 5) * 5));
    return { suggestedDiscount: discount, reasons };
  }

  function forecastDemand(pastOrderCounts = []) {
    if (!pastOrderCounts.length) {
      return { forecastUnits: 10, confidence: "low", note: "No history yet — default starter estimate" };
    }
    const avg = pastOrderCounts.reduce((a, b) => a + b, 0) / pastOrderCounts.length;
    const recent = pastOrderCounts.slice(-3);
    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const trendUp = recentAvg > avg;
    const forecastUnits = Math.round(trendUp ? recentAvg * 1.1 : recentAvg * 0.95);
    return {
      forecastUnits: Math.max(1, forecastUnits),
      confidence: pastOrderCounts.length >= 7 ? "high" : "medium",
      note: trendUp ? "Demand trending up vs. recent average" : "Demand steady/declining vs. recent average"
    };
  }

  const RECIPE_BANK = {
    bread: ["Bread upma", "French toast", "Bread pakora", "Breadcrumbs for cutlets"],
    vegetables: ["Mixed vegetable sabzi", "Vegetable soup", "Paratha stuffing", "Vegetable pulao"],
    fruits: ["Fruit chaat", "Smoothie", "Jam/preserve", "Fruit raita"],
    dairy: ["Paneer at home", "Lassi", "Curd-based curry", "Cheese sauce"],
    bakery: ["Bread pudding", "Cake rusk (re-bake and dry)", "Trifle with stale cake"],
    rice: ["Fried rice", "Rice kheer", "Rice cutlets", "Curd rice"],
    sweets: ["Repurpose into shakes", "Use as dessert topping", "Freeze for later"]
  };

  function suggestRecipes(category = "") {
    const key = Object.keys(RECIPE_BANK).find((k) => category.toLowerCase().includes(k));
    return key ? RECIPE_BANK[key] : ["Store airtight and consume within 1-2 days", "Freeze portions to extend shelf life"];
  }

  const BADGE_TIERS = [
    { name: "First Rescue", minKg: 0.1 },
    { name: "Food Saver", minKg: 5 },
    { name: "Eco Hero", minKg: 20 },
    { name: "Waste Warrior", minKg: 50 },
    { name: "Planet Protector", minKg: 100 }
  ];

  function badgesForTotal(totalKg) {
    return BADGE_TIERS.filter((b) => totalKg >= b.minKg).map((b) => b.name);
  }

  return { computeImpact, suggestDiscount, forecastDemand, suggestRecipes, badgesForTotal };
})();
