const state = {
  user: JSON.parse(localStorage.getItem("resq_user") || "null"),
  listings: [],
  cart: [], // [{listingId, title, unitFinalPrice, unitOriginalPrice, weightKgPerUnit, qty, sellerId, sellerName}]
  activeFilter: "all",
  flashOnly: false
};

// ---------------- helpers ----------------
function $(sel) { return document.querySelector(sel); }
function $all(sel) { return Array.from(document.querySelectorAll(sel)); }
function money(n) { return "₹" + Number(n || 0).toLocaleString("en-IN"); }

function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => t.classList.remove("show"), 2600);
}

// No server here — every "api" call is dispatched to Backend, which reads/writes
// localStorage via Store. Same call shape as the old fetch() version so the
// rest of this file barely had to change.
async function api(path, opts = {}) {
  const method = (opts.method || "GET").toUpperCase();
  const body = opts.body ? JSON.parse(opts.body) : {};
  return Backend.dispatch(method, path, body);
}

function persistUser() {
  localStorage.setItem("resq_user", JSON.stringify(state.user));
  refreshUserPill();
}

function refreshUserPill() {
  const pill = $("#pointsPill");
  if (state.user) {
    pill.classList.add("show");
    $("#pointsVal").textContent = state.user.points ?? 0;
    $("#loginBtn").textContent = state.user.name.split(" ")[0];
    $("#signupBtn").classList.add("hidden");
  } else {
    pill.classList.remove("show");
    $("#loginBtn").textContent = "Log in";
    $("#signupBtn").classList.remove("hidden");
  }
}

// ---------------- navigation ----------------
const VIEWS = ["browse", "box", "clubs", "dashboard", "sell"];
function showView(name) {
  VIEWS.forEach((v) => {
    const el = $("#view-" + v);
    if (el) el.style.display = v === name ? "" : "none";
  });
  $all(".nav-links button").forEach((b) => b.classList.toggle("active", b.dataset.nav === name));
  if (name === "dashboard") loadDashboard();
  if (name === "clubs") loadClubs();
  window.scrollTo({ top: document.querySelector(".site-header").nextElementSibling.offsetTop - 80, behavior: "smooth" });
}
$all("[data-nav]").forEach((el) => el.addEventListener("click", () => showView(el.dataset.nav)));

// ---------------- clock ----------------
function tickClock() {
  $("#clock").textContent = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}
setInterval(tickClock, 1000);
tickClock();

// ---------------- global board stats ----------------
async function loadGlobalStats() {
  try {
    const g = await api("/dashboard/global");
    $("#boardKg").textContent = g.todayFoodKg || g.allTimeFoodKg || 0;
    $("#boardCo2").textContent = g.todayCo2Kg || g.allTimeCo2Kg || 0;
    $("#boardMoney").textContent = money(g.todayMoneyInr || g.allTimeMoneyInr || 0);
    $("#statSellers").textContent = g.sellersCount ?? "–";
  } catch (e) { /* ignore */ }
}

// ---------------- listings ----------------
async function loadListings() {
  const grid = $("#listingsGrid");
  grid.innerHTML = "<p>Loading deals…</p>";
  try {
    const params = new URLSearchParams();
    if (state.activeFilter !== "all") params.set("category", state.activeFilter);
    if (state.flashOnly) params.set("flashSale", "true");
    const listings = await api("/listings?" + params.toString());
    state.listings = listings;
    $("#statListings").textContent = listings.length;
    renderTicker(listings);
    renderGrid(listings);
  } catch (e) {
    grid.innerHTML = `<p>Couldn't load deals: ${e.message}</p>`;
  }
}

function renderTicker(listings) {
  const track = $("#tickerTrack");
  if (!listings.length) { track.innerHTML = "<span class='ticker-item'>No live deals right now — check back soon.</span>"; return; }
  const items = listings.slice(0, 10).map((l) =>
    `<span class="ticker-item">${l.sellerName} — ${l.title} <span class="pct">${l.discountPercent}% OFF</span></span>`
  );
  track.innerHTML = items.concat(items).join(""); // duplicate for seamless loop
}

function formatCountdown(hoursLeft) {
  if (hoursLeft <= 0) return "Pickup window closed";
  const h = Math.floor(hoursLeft);
  const m = Math.round((hoursLeft - h) * 60);
  return h > 0 ? `${h}h ${m}m left to pick up` : `${m}m left — flash sale!`;
}

function renderGrid(listings) {
  const grid = $("#listingsGrid");
  if (!listings.length) { grid.innerHTML = "<p>No deals match this filter right now.</p>"; return; }
  grid.innerHTML = listings.map((l) => `
    <div class="card" data-id="${l.id}">
      <div class="tag-row">
        <span class="tag discount">${l.discountPercent}% OFF</span>
        ${l.flashSale ? '<span class="tag flash">⚡ Flash sale</span>' : ""}
        ${l.isFamilyPack ? '<span class="tag eco">Family pack</span>' : ""}
        ${l.isMysteryBox ? '<span class="tag eco">Mystery box</span>' : ""}
      </div>
      <h4>${l.title}</h4>
      <div class="shop">${l.sellerName} · ${l.shopType.replace("_", " ")} · ${l.city || ""}</div>
      <div class="price-row"><span class="price-final mono">₹${l.finalPrice}</span><span class="price-orig mono">₹${l.originalPrice}</span></div>
      <div class="countdown">⏱ ${formatCountdown(l.hoursLeft)} · ${l.quantityRemaining} left</div>
      <div class="card-footer">
        <input type="number" min="1" max="${l.quantityRemaining}" value="1" class="qty-input" id="qty-${l.id}"/>
        <button class="btn btn-marigold btn-sm" style="flex:1;" data-add="${l.id}">Add to box</button>
      </div>
    </div>
  `).join("");

  $all("[data-add]").forEach((btn) => btn.addEventListener("click", () => addToCart(btn.dataset.add)));
}

$all(".chip[data-filter]").forEach((chip) => {
  chip.addEventListener("click", () => {
    $all(".chip[data-filter]").forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");
    state.activeFilter = chip.dataset.filter;
    loadListings();
  });
});
$("[data-flash]") // flash-only chip
  ?.addEventListener("click", function () {
    state.flashOnly = !state.flashOnly;
    this.classList.toggle("active", state.flashOnly);
    loadListings();
  });

// ---------------- cart / custom box ----------------
function addToCart(listingId) {
  const listing = state.listings.find((l) => l.id === listingId);
  if (!listing) return;
  const qtyInput = $("#qty-" + listingId);
  const qty = Math.max(1, Math.min(listing.quantityRemaining, Number(qtyInput.value) || 1));

  if (state.cart.length && state.cart[0].sellerId !== listing.sellerId) {
    toast("A box can only hold items from one seller — checkout or clear your current box first.");
    return;
  }

  const existing = state.cart.find((c) => c.listingId === listingId);
  if (existing) existing.qty = Math.min(listing.quantityRemaining, existing.qty + qty);
  else state.cart.push({
    listingId, title: listing.title, qty,
    unitFinalPrice: listing.finalPrice, unitOriginalPrice: listing.originalPrice,
    weightKgPerUnit: listing.weightKgPerUnit, sellerId: listing.sellerId, sellerName: listing.sellerName,
    category: listing.category
  });

  renderCart();
  toast(`Added "${listing.title}" to your box`);
  showView("box");
}

function renderCart() {
  const linesEl = $("#cartLines");
  if (!state.cart.length) {
    linesEl.innerHTML = `<p style="opacity:.7;font-size:13.5px;">Empty — add something delicious.</p>`;
    $("#cartTotal").textContent = "₹0";
    $("#cartSavings").textContent = "You'll save ₹0 vs. original price";
    $("#recipeBox").classList.add("hidden");
    return;
  }
  linesEl.innerHTML = state.cart.map((c) => `
    <div class="cart-line">
      <span>${c.title} × ${c.qty}</span>
      <span class="mono">${money(c.unitFinalPrice * c.qty)}</span>
    </div>
  `).join("");

  const donation = Number($("#donationInput").value) || 0;
  const subtotal = state.cart.reduce((s, c) => s + c.unitFinalPrice * c.qty, 0);
  const original = state.cart.reduce((s, c) => s + c.unitOriginalPrice * c.qty, 0);
  const subDiscount = state.user?.subscription ? subtotal * 0.1 : 0;
  const total = subtotal - subDiscount + donation;

  $("#cartTotal").textContent = money(total);
  $("#cartSavings").textContent = `You'll save ${money(original - subtotal)} vs. original price` + (subDiscount ? ` (+${money(subDiscount)} member discount)` : "");

  // Recipe suggestions for first item's category
  fetchRecipes(state.cart[0].category);
}

async function fetchRecipes(category) {
  try {
    const listing = state.listings.find((l) => l.category === category);
    if (!listing) return;
    const full = await api(`/listings/${listing.id}`);
    const box = $("#recipeBox");
    const list = $("#recipeList");
    if (full.recipeSuggestions?.length) {
      list.innerHTML = full.recipeSuggestions.map((r) => `<li>${r}</li>`).join("");
      box.classList.remove("hidden");
    }
  } catch (e) { /* silent */ }
}

$("#donationInput").addEventListener("input", renderCart);

$("#checkoutBtn").addEventListener("click", async () => {
  if (!state.user) { openAuth("login"); toast("Log in to check out"); return; }
  if (!state.cart.length) { toast("Your box is empty"); return; }
  try {
    const donationInr = Number($("#donationInput").value) || 0;
    const items = state.cart.map((c) => ({ listingId: c.listingId, qty: c.qty }));
    const result = await api("/orders", { method: "POST", body: JSON.stringify({ userId: state.user.id, items, donationInr }) });
    state.user = result.user;
    persistUser();
    state.cart = [];
    renderCart();
    toast(`Order confirmed! You rescued ${result.impact.foodKg}kg of food and saved ${result.impact.co2SavedKg}kg CO₂ 🎉`);
    loadListings();
    loadGlobalStats();
    showView("dashboard");
  } catch (e) {
    toast("Checkout failed: " + e.message);
  }
});

// ---------------- auth ----------------
let authMode = "login";
function openAuth(mode) {
  authMode = mode;
  $("#authTitle").textContent = mode === "login" ? "Log in" : "Sign up";
  $("#authSubmitBtn").textContent = mode === "login" ? "Log in" : "Create account";
  $("#nameRow").classList.toggle("hidden", mode === "login");
  $("#phoneRow").classList.toggle("hidden", mode === "login");
  $("#toggleAuthMode").textContent = mode === "login" ? "Need an account? Sign up" : "Already have an account? Log in";
  $("#authAlert").innerHTML = "";
  $("#authModal").classList.remove("hidden");
}
$("#loginBtn").addEventListener("click", () => state.user ? showView("dashboard") : openAuth("login"));
$("#signupBtn").addEventListener("click", () => openAuth("signup"));
$("#dashLoginBtn").addEventListener("click", () => openAuth("login"));
$("#closeAuthBtn").addEventListener("click", () => $("#authModal").classList.add("hidden"));
$("#toggleAuthMode").addEventListener("click", (e) => { e.preventDefault(); openAuth(authMode === "login" ? "signup" : "login"); });

$("#authSubmitBtn").addEventListener("click", async () => {
  const email = $("#a_email").value.trim();
  const password = $("#a_password").value;
  try {
    let data;
    if (authMode === "login") {
      data = await api("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
    } else {
      const name = $("#a_name").value.trim();
      const phone = $("#a_phone").value.trim();
      data = await api("/auth/register", { method: "POST", body: JSON.stringify({ name, email, phone, password }) });
    }
    state.user = data.user;
    persistUser();
    $("#authModal").classList.add("hidden");
    toast(`Welcome${authMode === "signup" ? "" : " back"}, ${state.user.name.split(" ")[0]}!`);
    renderCart();
    if ($("#view-dashboard").style.display !== "none") loadDashboard();
  } catch (e) {
    $("#authAlert").innerHTML = `<div class="alert error">${e.message}</div>`;
  }
});

// ---------------- dashboard ----------------
async function loadDashboard() {
  if (!state.user) {
    $("#dashboardLoggedOut").classList.remove("hidden");
    $("#dashboardContent").classList.add("hidden");
    return;
  }
  $("#dashboardLoggedOut").classList.add("hidden");
  $("#dashboardContent").classList.remove("hidden");
  try {
    const u = await api(`/dashboard/user/${state.user.id}`);
    $("#dashKg").textContent = `${u.totalFoodKg} kg`;
    $("#dashCo2").textContent = `${u.totalCo2Kg} kg`;
    $("#dashWater").textContent = `${u.totalWaterL} L`;
    $("#dashMoney").textContent = money(u.totalMoneySavedInr);
    $("#equivText").textContent = `≈ ${u.equivalents.treesEquivalent} trees' worth of CO₂ absorbed per year, or ${u.equivalents.carKmAvoided} km of car emissions avoided.`;

    const pct = Math.min(100, (u.totalFoodKg / 25) * 100); // scale gauge to a 25kg "hero" milestone
    const circumference = 326.7;
    $("#gaugeCircle").setAttribute("stroke-dashoffset", circumference - (circumference * pct) / 100);
    $("#gaugeText").textContent = Math.round(pct) + "%";

    $("#badgeRow").innerHTML = u.badges?.length
      ? u.badges.map((b) => `<span class="badge-pill">${b}</span>`).join("")
      : `<span style="color:var(--ink-soft); font-size:13px;">Place your first order to earn "First Rescue" 🎉</span>`;

    const leaders = await api("/dashboard/leaderboard");
    $("#leaderboardCard").innerHTML = leaders.length
      ? leaders.map((l, i) => `
          <div class="leader-row">
            <span class="leader-rank">#${i + 1}</span>
            <span class="leader-name">${l.name}</span>
            <span style="font-size:12px;color:var(--ink-soft);">${l.totalFoodKg}kg</span>
            <span class="leader-pts">${l.points} pts</span>
          </div>`).join("")
      : "<p>No rescues yet — be the first!</p>";
  } catch (e) {
    toast("Couldn't load dashboard: " + e.message);
  }
}

// ---------------- clubs ----------------
async function loadClubs() {
  try {
    const clubs = await api("/clubs");
    const grid = $("#clubsGrid");
    if (!clubs.length) { grid.innerHTML = `<p style="color:var(--ink-soft);">No open clubs yet — start one from the demo button below.</p>`; return; }
    grid.innerHTML = clubs.map((c) => `
      <div class="card">
        <h4>${c.title}</h4>
        <div class="shop">${c.sellerName}</div>
        <p style="font-size:13.5px; color:var(--ink-soft);">${c.members.length}/${c.minMembers} neighbours joined · +${c.bonusDiscountPercent}% bonus discount when unlocked</p>
        <span class="tag ${c.status === 'unlocked' ? 'eco' : 'discount'}">${c.status.toUpperCase()}</span>
        <button class="btn btn-marigold btn-sm" data-join="${c.id}" ${c.status !== 'open' ? 'disabled' : ''}>Join this club</button>
      </div>
    `).join("");
    $all("[data-join]").forEach((btn) => btn.addEventListener("click", () => joinClub(btn.dataset.join)));
  } catch (e) { /* ignore */ }
}

async function joinClub(clubId) {
  if (!state.user) { openAuth("login"); toast("Log in to join a rescue club"); return; }
  try {
    const club = await api(`/clubs/${clubId}/join`, { method: "POST", body: JSON.stringify({ userId: state.user.id }) });
    toast(club.status === "unlocked" ? "🎉 Club unlocked! Bonus discount applied." : "Joined — waiting for more neighbours.");
    loadClubs();
    loadListings();
  } catch (e) { toast(e.message); }
}

$("#demoClubBtn").addEventListener("click", async () => {
  const flashListing = state.listings.find((l) => l.flashSale) || state.listings[0];
  if (!flashListing) { toast("No listings available yet"); return; }
  try {
    await api("/clubs", { method: "POST", body: JSON.stringify({ listingId: flashListing.id, minMembers: 5, bonusDiscountPercent: 15, creatorUserId: state.user?.id }) });
    toast("Demo club created!");
    loadClubs();
  } catch (e) { toast(e.message); }
});

// ---------------- seller registration ----------------
$("#sellerSubmitBtn").addEventListener("click", async () => {
  const body = {
    businessName: $("#s_businessName").value.trim(),
    ownerName: $("#s_ownerName").value.trim(),
    shopType: $("#s_shopType").value,
    email: $("#s_email").value.trim(),
    phone: $("#s_phone").value.trim(),
    password: $("#s_password").value,
    fssaiLicense: $("#s_fssai").value.trim(),
    gstNumber: $("#s_gst").value.trim(),
    address: $("#s_address").value.trim(),
    city: $("#s_city").value.trim()
  };
  const alertBox = $("#sellerAlert");
  try {
    const data = await api("/sellers/register", { method: "POST", body: JSON.stringify(body) });
    alertBox.innerHTML = `<div class="alert success">Registered! Your seller ID is <strong>${data.seller.id}</strong> — save this. Verification is pending (demo tip: verification auto-approves in this build after ~2s so you can try listing).</div>`;
    $("#l_sellerId").value = data.seller.id;
    // Demo convenience: auto-verify so reviewers can immediately test listing creation.
    setTimeout(() => api(`/sellers/${data.seller.id}/verify`, { method: "POST" }).catch(() => {}), 1500);
  } catch (e) {
    alertBox.innerHTML = `<div class="alert error">${e.message}</div>`;
  }
});

$("#askAiPriceBtn").addEventListener("click", async () => {
  const sellerId = $("#l_sellerId").value.trim();
  const hours = Number($("#l_hours").value) || 4;
  // Use a temp listing-independent heuristic call via listings AI endpoint isn't possible without an id,
  // so we approximate using the same engine logic client-side messaging + server suggestion via a scratch listing.
  try {
    const price = Number($("#l_price").value) || 100;
    const qty = Number($("#l_qty").value) || 10;
    const weight = Number($("#l_weight").value) || 1;
    const draft = await api("/listings", {
      method: "POST",
      body: JSON.stringify({
        sellerId, title: "(AI pricing draft)", category: $("#l_category").value, originalPrice: price,
        discountPercent: 50, quantityTotal: qty, weightKgPerUnit: weight,
        pickupBy: new Date(Date.now() + hours * 3600000).toISOString()
      })
    }).catch((e) => { throw new Error("Register and get verified first, or paste a valid seller ID."); });
    const suggestion = await api(`/listings/${draft.id}/ai-price`);
    $("#l_discount").value = suggestion.suggestedDiscount;
    $("#aiPriceSuggestion").innerHTML = `Suggested discount: <strong>${suggestion.suggestedDiscount}%</strong><br/>${suggestion.reasons.map(r => "• " + r).join("<br/>")}`;
  } catch (e) {
    $("#aiPriceSuggestion").textContent = e.message;
  }
});

$("#listingSubmitBtn").addEventListener("click", async () => {
  const body = {
    sellerId: $("#l_sellerId").value.trim(),
    title: $("#l_title").value.trim(),
    category: $("#l_category").value,
    originalPrice: Number($("#l_price").value),
    discountPercent: Number($("#l_discount").value),
    weightKgPerUnit: Number($("#l_weight").value),
    quantityTotal: Number($("#l_qty").value),
    pickupBy: new Date(Date.now() + (Number($("#l_hours").value) || 4) * 3600000).toISOString()
  };
  const alertBox = $("#listingAlert");
  try {
    await api("/listings", { method: "POST", body: JSON.stringify(body) });
    alertBox.innerHTML = `<div class="alert success">Listing published! It's now live in Browse deals.</div>`;
    loadListings();
    loadGlobalStats();
  } catch (e) {
    alertBox.innerHTML = `<div class="alert error">${e.message}</div>`;
  }
});

document.getElementById("resetDataLink")?.addEventListener("click", async (e) => {
  e.preventDefault();
  if (!confirm("This clears all local demo data (sellers, listings, your account, orders) and reseeds fresh demo data. Continue?")) return;
  Store.resetAll();
  localStorage.removeItem("resq_user");
  location.reload();
});

// ---------------- init ----------------
(async function init() {
  await seedIfEmpty(); // first-visit only — safe to call every time
  refreshUserPill();
  await loadListings();
  await loadGlobalStats();
  showView("browse");
  setInterval(loadListings, 60000); // keep countdowns/flash sales fresh
})();
