// js/backend.js
// Everything that used to be an Express route in server/routes/*.js, ported
// to run directly in the browser against Store (localStorage). app.js talks
// to this exactly the way it used to talk to fetch() — same paths, same
// methods, same request/response shapes — via Backend.dispatch().

const Backend = (() => {
  const SHOP_TYPES = ["restaurant", "supermarket", "bakery", "sweet_shop", "tiffin_service", "caterer", "grocery", "individual", "other"];

  function err(message) {
    const e = new Error(message);
    return e;
  }

  function hoursUntil(iso) {
    return (new Date(iso).getTime() - Date.now()) / (1000 * 60 * 60);
  }

  function withLiveState(listing) {
    const hrsLeft = hoursUntil(listing.pickupBy);
    let discountPercent = listing.discountPercent;
    let flashSale = listing.flashSale;

    if (listing.category === "bakery" && listing.bakedAt) {
      const hrsSinceBaked = (Date.now() - new Date(listing.bakedAt).getTime()) / 3600000;
      if (hrsSinceBaked >= (listing.bakeryFreshHours || 4)) discountPercent = Math.max(discountPercent, 70);
    }
    if (hrsLeft <= 0.5 && hrsLeft > 0) {
      flashSale = true;
      discountPercent = Math.max(discountPercent, 75);
    }
    discountPercent = Validators.enforceMinDiscount(discountPercent);
    const finalPrice = +(listing.originalPrice * (1 - discountPercent / 100)).toFixed(2);
    return { ...listing, discountPercent, finalPrice, flashSale, hoursLeft: +hrsLeft.toFixed(2), expired: hrsLeft <= 0 };
  }

  function safe(record) {
    if (!record) return record;
    const { passwordHash, ...rest } = record;
    return rest;
  }

  // ---------------- auth ----------------
  async function authRegister({ name, email, phone, password }) {
    if (!name || !Validators.isValidEmail(email) || !Validators.isValidIndianPhone(phone) || !password || password.length < 6) {
      throw err("Invalid name/email/10-digit Indian phone/password (min 6 chars)");
    }
    if (Store.find("users", (u) => u.email === email)) throw err("Email already registered");
    const user = {
      id: CryptoUtils.uuid(), role: "buyer", name, email, phone,
      passwordHash: await CryptoUtils.hashPassword(password),
      subscription: false, points: 0, totalFoodKg: 0, totalCo2Kg: 0, totalWaterL: 0,
      totalMoneySavedInr: 0, badges: [], createdAt: new Date().toISOString()
    };
    Store.insert("users", user);
    return { user: safe(user) };
  }

  async function authLogin({ email, password }) {
    const user = Store.find("users", (u) => u.email === email);
    if (!user || !(await CryptoUtils.verifyPassword(password || "", user.passwordHash))) throw err("Invalid email or password");
    return { user: safe(user) };
  }

  // ---------------- sellers ----------------
  async function sellerRegister(body) {
    const { businessName, ownerName, email, phone, password, shopType, fssaiLicense, gstNumber, address, city } = body;
    if (!businessName || !ownerName || !Validators.isValidEmail(email) || !Validators.isValidIndianPhone(phone) || !password) {
      throw err("Missing/invalid business name, owner name, email, phone, or password");
    }
    if (!SHOP_TYPES.includes(shopType)) throw err(`shopType must be one of: ${SHOP_TYPES.join(", ")}`);
    if (!Validators.isValidFssai(fssaiLicense)) {
      throw err("A valid 14-digit Indian FSSAI license number is mandatory to sell food on this platform.");
    }
    if (gstNumber && !Validators.isValidGst(gstNumber)) throw err("GST number format looks invalid");
    if (Store.find("sellers", (s) => s.email === email)) throw err("Email already registered");
    if (Store.find("sellers", (s) => s.fssaiLicense === fssaiLicense)) throw err("This FSSAI license number is already registered to another account");

    const seller = {
      id: CryptoUtils.uuid(), role: "seller", businessName, ownerName, email, phone,
      passwordHash: await CryptoUtils.hashPassword(password),
      shopType, fssaiLicense, gstNumber: gstNumber || null, address: address || "", city: city || "",
      verified: false, verificationStatus: "pending_manual_review", subscriptionPlan: "free", featured: false,
      rating: 0, totalOrders: 0, totalFoodKgRescued: 0, totalMoneyRecoveredInr: 0, totalCo2SavedKg: 0,
      createdAt: new Date().toISOString()
    };
    Store.insert("sellers", seller);
    return { seller: safe(seller), note: "Registered. Verification pending." };
  }

  async function sellerVerify(id) {
    const seller = Store.update("sellers", id, { verified: true, verificationStatus: "verified" });
    if (!seller) throw err("Seller not found");
    return { seller: safe(seller) };
  }

  function sellersList() {
    return Store.all("sellers").map(safe);
  }

  function sellerForecast(id) {
    const orders = Store.filter("orders", (o) => o.sellerId === id);
    const byDay = {};
    orders.forEach((o) => {
      const day = o.createdAt.slice(0, 10);
      byDay[day] = (byDay[day] || 0) + o.items.reduce((s, i) => s + i.qty, 0);
    });
    return AI.forecastDemand(Object.values(byDay));
  }

  // ---------------- listings ----------------
  function listingsList(params) {
    let listings = Store.all("listings").map(withLiveState).filter((l) => !l.expired && l.quantityRemaining > 0);
    const category = params.get("category");
    const shopType = params.get("shopType");
    const flashSale = params.get("flashSale");
    const city = params.get("city");
    const sellerId = params.get("sellerId");
    const maxMinutesLeft = params.get("maxMinutesLeft");
    if (category) listings = listings.filter((l) => l.category === category);
    if (shopType) listings = listings.filter((l) => l.shopType === shopType);
    if (sellerId) listings = listings.filter((l) => l.sellerId === sellerId);
    if (flashSale === "true") listings = listings.filter((l) => l.flashSale);
    if (city) listings = listings.filter((l) => (l.city || "").toLowerCase() === city.toLowerCase());
    if (maxMinutesLeft) listings = listings.filter((l) => l.hoursLeft * 60 <= Number(maxMinutesLeft));
    listings.sort((a, b) => a.hoursLeft - b.hoursLeft);
    return listings;
  }

  function listingGet(id) {
    const listing = Store.find("listings", (l) => l.id === id);
    if (!listing) throw err("Listing not found");
    const live = withLiveState(listing);
    return { ...live, recipeSuggestions: AI.suggestRecipes(live.category) };
  }

  function listingCreate(body) {
    const { sellerId, title, description, category, shopType, originalPrice, discountPercent,
      quantityTotal, unit, weightKgPerUnit, pickupBy, city, isFamilyPack, isMysteryBox, bakedAt, bakeryFreshHours } = body;

    const seller = Store.find("sellers", (s) => s.id === sellerId);
    if (!seller) throw err("Seller not found");
    if (!seller.verified) throw err("Seller not yet verified. Listings can only be created after FSSAI license verification.");
    if (!title || !category || !originalPrice || !quantityTotal || !pickupBy) {
      throw err("Missing required fields: title, category, originalPrice, quantityTotal, pickupBy");
    }
    const listing = {
      id: CryptoUtils.uuid(), sellerId, sellerName: seller.businessName, shopType: shopType || seller.shopType,
      title, description: description || "", category, originalPrice: Number(originalPrice),
      discountPercent: Validators.enforceMinDiscount(discountPercent),
      quantityTotal: Number(quantityTotal), quantityRemaining: Number(quantityTotal),
      unit: unit || "unit", weightKgPerUnit: Number(weightKgPerUnit) || 0.5, pickupBy,
      city: city || seller.city, isFamilyPack: !!isFamilyPack, isMysteryBox: !!isMysteryBox,
      flashSale: false, bakedAt: bakedAt || null, bakeryFreshHours: bakeryFreshHours || 4,
      createdAt: new Date().toISOString()
    };
    Store.insert("listings", listing);
    return withLiveState(listing);
  }

  function listingAiPrice(id, params) {
    const listing = Store.find("listings", (l) => l.id === id);
    if (!listing) throw err("Listing not found");
    const hrsLeft = Math.max(0, hoursUntil(listing.pickupBy));
    const demandScore = Math.min(1, (listing.views || 0) / 50 || 0.5);
    const isRaining = params.get("isRaining") === "true";
    return AI.suggestDiscount({ hoursToExpiry: hrsLeft, demandScore, isRaining });
  }

  // ---------------- orders ----------------
  function ordersCreate(body) {
    const { userId, items, donationInr = 0, fulfillment = "pickup" } = body;
    const user = Store.find("users", (u) => u.id === userId);
    if (!user) throw err("User not found");
    if (!Array.isArray(items) || items.length === 0) throw err("Cart is empty");

    let subtotal = 0, originalTotal = 0, foodKg = 0, sellerId = null;
    const orderItems = [];

    for (const item of items) {
      const listing = Store.find("listings", (l) => l.id === item.listingId);
      if (!listing) throw err(`Listing ${item.listingId} not found`);
      if (item.qty > listing.quantityRemaining) throw err(`Only ${listing.quantityRemaining} left of "${listing.title}"`);
      sellerId = sellerId || listing.sellerId;
      if (sellerId !== listing.sellerId) throw err("A custom box can only contain items from one seller per order");

      const lineFinalPrice = +(listing.originalPrice * (1 - listing.discountPercent / 100) * item.qty).toFixed(2);
      const lineOriginalPrice = +(listing.originalPrice * item.qty).toFixed(2);
      subtotal += lineFinalPrice;
      originalTotal += lineOriginalPrice;
      foodKg += (listing.weightKgPerUnit || 0.5) * item.qty;

      orderItems.push({
        listingId: listing.id, title: listing.title, qty: item.qty,
        unitFinalPrice: +(listing.originalPrice * (1 - listing.discountPercent / 100)).toFixed(2),
        discountPercent: listing.discountPercent
      });
      Store.update("listings", listing.id, { quantityRemaining: listing.quantityRemaining - item.qty });
    }

    const subscriptionDiscount = user.subscription ? +(subtotal * 0.1).toFixed(2) : 0;
    const total = +(subtotal - subscriptionDiscount + Number(donationInr || 0)).toFixed(2);
    const moneySaved = +(originalTotal - subtotal).toFixed(2);
    const impact = AI.computeImpact(foodKg);

    const order = {
      id: CryptoUtils.uuid(), userId, sellerId, items: orderItems, fulfillment,
      subtotal: +subtotal.toFixed(2), subscriptionDiscount, donationInr: Number(donationInr || 0),
      total, originalTotal: +originalTotal.toFixed(2), moneySavedInr: moneySaved,
      foodSavedKg: impact.foodKg, co2SavedKg: impact.co2SavedKg, waterSavedL: impact.waterSavedL,
      pointsEarned: impact.points, status: "confirmed", createdAt: new Date().toISOString()
    };
    Store.insert("orders", order);

    const newTotalKg = user.totalFoodKg + impact.foodKg;
    const updatedUser = Store.update("users", userId, {
      points: user.points + impact.points,
      totalFoodKg: +newTotalKg.toFixed(2),
      totalCo2Kg: +(user.totalCo2Kg + impact.co2SavedKg).toFixed(2),
      totalWaterL: user.totalWaterL + impact.waterSavedL,
      totalMoneySavedInr: +(user.totalMoneySavedInr + moneySaved).toFixed(2),
      badges: AI.badgesForTotal(newTotalKg)
    });

    const seller = Store.find("sellers", (s) => s.id === sellerId);
    if (seller) {
      Store.update("sellers", sellerId, {
        totalOrders: seller.totalOrders + 1,
        totalFoodKgRescued: +(seller.totalFoodKgRescued + impact.foodKg).toFixed(2),
        totalMoneyRecoveredInr: +(seller.totalMoneyRecoveredInr + subtotal).toFixed(2),
        totalCo2SavedKg: +(seller.totalCo2SavedKg + impact.co2SavedKg).toFixed(2)
      });
    }
    return { order, impact, user: safe(updatedUser) };
  }

  // ---------------- dashboard ----------------
  function dashboardUser(id) {
    const user = Store.find("users", (u) => u.id === id);
    if (!user) throw err("User not found");
    const orders = Store.filter("orders", (o) => o.userId === id);
    const byMonth = {};
    orders.forEach((o) => {
      const month = o.createdAt.slice(0, 7);
      byMonth[month] = byMonth[month] || { foodKg: 0, co2Kg: 0, moneyInr: 0, orders: 0 };
      byMonth[month].foodKg += o.foodSavedKg;
      byMonth[month].co2Kg += o.co2SavedKg;
      byMonth[month].moneyInr += o.moneySavedInr;
      byMonth[month].orders += 1;
    });
    return {
      ...safe(user), ordersCount: orders.length,
      monthly: Object.entries(byMonth).map(([month, v]) => ({ month, ...v })),
      equivalents: {
        treesEquivalent: +(user.totalCo2Kg / 21).toFixed(2),
        carKmAvoided: +(user.totalCo2Kg / 0.12).toFixed(1)
      }
    };
  }

  function dashboardSeller(id) {
    const seller = Store.find("sellers", (s) => s.id === id);
    if (!seller) throw err("Seller not found");
    const orders = Store.filter("orders", (o) => o.sellerId === id);
    const listings = Store.filter("listings", (l) => l.sellerId === id);
    const productCounts = {}, hourCounts = {};
    orders.forEach((o) => {
      o.items.forEach((it) => { productCounts[it.title] = (productCounts[it.title] || 0) + it.qty; });
      const hr = new Date(o.createdAt).getHours();
      hourCounts[hr] = (hourCounts[hr] || 0) + 1;
    });
    const popularProducts = Object.entries(productCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([title, qty]) => ({ title, qty }));
    const peakHours = Object.entries(hourCounts).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([hour, count]) => ({ hour: `${hour}:00`, count }));
    return { ...safe(seller), activeListings: listings.filter((l) => l.quantityRemaining > 0).length, popularProducts, peakHours };
  }

  function dashboardGlobal() {
    const orders = Store.all("orders");
    const today = new Date().toISOString().slice(0, 10);
    const todays = orders.filter((o) => o.createdAt.slice(0, 10) === today);
    const sum = (arr, key) => +arr.reduce((s, o) => s + (o[key] || 0), 0).toFixed(2);
    return {
      todayFoodKg: sum(todays, "foodSavedKg"), todayCo2Kg: sum(todays, "co2SavedKg"), todayMoneyInr: sum(todays, "moneySavedInr"),
      allTimeFoodKg: sum(orders, "foodSavedKg"), allTimeCo2Kg: sum(orders, "co2SavedKg"), allTimeMoneyInr: sum(orders, "moneySavedInr"),
      sellersCount: Store.all("sellers").filter((s) => s.verified).length, ordersCount: orders.length
    };
  }

  function dashboardLeaderboard() {
    return Store.all("users").sort((a, b) => b.points - a.points).slice(0, 20)
      .map((u) => ({ name: u.name, points: u.points, totalFoodKg: u.totalFoodKg, badges: u.badges }));
  }

  // ---------------- clubs ----------------
  function clubsCreate(body) {
    const { listingId, minMembers = 5, creatorUserId, bonusDiscountPercent = 10 } = body;
    const listing = Store.find("listings", (l) => l.id === listingId);
    if (!listing) throw err("Listing not found");
    const club = {
      id: CryptoUtils.uuid(), listingId, sellerName: listing.sellerName, title: listing.title,
      minMembers: Number(minMembers), bonusDiscountPercent: Number(bonusDiscountPercent),
      members: creatorUserId ? [creatorUserId] : [], status: "open", createdAt: new Date().toISOString()
    };
    Store.insert("clubs", club);
    return club;
  }

  function clubsJoin(id, { userId }) {
    const club = Store.find("clubs", (c) => c.id === id);
    if (!club) throw err("Club not found");
    if (club.status !== "open") throw err("This club is no longer accepting members");
    const members = Array.from(new Set([...club.members, userId]));
    const unlocked = members.length >= club.minMembers;
    const updated = Store.update("clubs", club.id, { members, status: unlocked ? "unlocked" : "open" });
    if (unlocked) {
      const listing = Store.find("listings", (l) => l.id === club.listingId);
      if (listing) Store.update("listings", listing.id, { discountPercent: Math.min(90, listing.discountPercent + club.bonusDiscountPercent) });
    }
    return updated;
  }

  function clubsList() {
    return Store.all("clubs").sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  // ---------------- subscriptions ----------------
  function subscriptionsToggle(userId, { activate = true }) {
    const user = Store.update("users", userId, { subscription: !!activate });
    if (!user) throw err("User not found");
    return { user: safe(user) };
  }

  // ---------------- dispatcher (mirrors the old fetch(API + path) calls) ----------------
  async function dispatch(method, rawPath, body) {
    const url = new URL(rawPath, "http://local");
    const path = url.pathname;
    const params = url.searchParams;
    const seg = path.split("/").filter(Boolean); // e.g. ['listings', ':id', 'ai-price']

    if (method === "POST" && path === "/auth/register") return authRegister(body);
    if (method === "POST" && path === "/auth/login") return authLogin(body);

    if (method === "POST" && path === "/sellers/register") return sellerRegister(body);
    if (method === "POST" && seg[0] === "sellers" && seg[2] === "verify") return sellerVerify(seg[1]);
    if (method === "GET" && path === "/sellers") return sellersList();
    if (method === "GET" && seg[0] === "sellers" && seg[2] === "forecast") return sellerForecast(seg[1]);

    if (method === "GET" && path === "/listings") return listingsList(params);
    if (method === "GET" && seg[0] === "listings" && seg.length === 2) return listingGet(seg[1]);
    if (method === "POST" && path === "/listings") return listingCreate(body);
    if (method === "GET" && seg[0] === "listings" && seg[2] === "ai-price") return listingAiPrice(seg[1], params);

    if (method === "POST" && path === "/orders") return ordersCreate(body);

    if (method === "GET" && path === "/dashboard/global") return dashboardGlobal();
    if (method === "GET" && path === "/dashboard/leaderboard") return dashboardLeaderboard();
    if (method === "GET" && seg[0] === "dashboard" && seg[1] === "user") return dashboardUser(seg[2]);
    if (method === "GET" && seg[0] === "dashboard" && seg[1] === "seller") return dashboardSeller(seg[2]);

    if (method === "GET" && path === "/clubs") return clubsList();
    if (method === "POST" && path === "/clubs") return clubsCreate(body);
    if (method === "POST" && seg[0] === "clubs" && seg[2] === "join") return clubsJoin(seg[1], body);

    if (method === "POST" && seg[0] === "subscriptions") return subscriptionsToggle(seg[1], body);

    throw err(`No route: ${method} ${path}`);
  }

  return { dispatch };
})();
