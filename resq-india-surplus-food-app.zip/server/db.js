// server/db.js
//
// Minimal file-based JSON datastore. This keeps the whole project dependency-free
// of native modules (no build toolchain needed) so it runs anywhere with just
// `npm install && npm start`. For production, swap this module for
// PostgreSQL / MongoDB — every route only talks to db.js, never to files directly,
// so the swap is contained to this one file.

const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");
const FILE = path.join(DATA_DIR, "store.json");

const DEFAULT_STATE = {
  users: [],       // buyers
  sellers: [],      // shops/restaurants/bakeries/supermarkets
  listings: [],      // surplus food items
  orders: [],       // completed orders
  clubs: [],        // neighborhood rescue clubs (group buys)
  admin_log: []
};

function ensureFile() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILE)) {
    fs.writeFileSync(FILE, JSON.stringify(DEFAULT_STATE, null, 2));
  }
}

function readAll() {
  ensureFile();
  const raw = fs.readFileSync(FILE, "utf-8");
  try {
    return JSON.parse(raw);
  } catch (e) {
    return { ...DEFAULT_STATE };
  }
}

function writeAll(state) {
  fs.writeFileSync(FILE, JSON.stringify(state, null, 2));
}

// Generic collection helpers -------------------------------------------------

function all(collection) {
  const state = readAll();
  return state[collection] || [];
}

function find(collection, predicate) {
  return all(collection).find(predicate);
}

function filter(collection, predicate) {
  return all(collection).filter(predicate);
}

function insert(collection, record) {
  const state = readAll();
  if (!state[collection]) state[collection] = [];
  state[collection].push(record);
  writeAll(state);
  return record;
}

function update(collection, id, patch) {
  const state = readAll();
  const list = state[collection] || [];
  const idx = list.findIndex((r) => r.id === id);
  if (idx === -1) return null;
  list[idx] = { ...list[idx], ...patch };
  writeAll(state);
  return list[idx];
}

function remove(collection, id) {
  const state = readAll();
  const list = state[collection] || [];
  state[collection] = list.filter((r) => r.id !== id);
  writeAll(state);
}

module.exports = { all, find, filter, insert, update, remove, readAll, writeAll };
