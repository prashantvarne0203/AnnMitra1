const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { v4: uuid } = require("uuid");
const db = require("../db");
const { isValidEmail, isValidIndianPhone } = require("../utils/validators");

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";

// POST /api/auth/register  (consumers only — sellers use /api/sellers/register)
router.post("/register", (req, res) => {
  const { name, email, phone, password } = req.body;
  if (!name || !isValidEmail(email) || !isValidIndianPhone(phone) || !password || password.length < 6) {
    return res.status(400).json({ error: "Invalid name/email/10-digit Indian phone/password (min 6 chars)" });
  }
  if (db.find("users", (u) => u.email === email)) {
    return res.status(409).json({ error: "Email already registered" });
  }
  const user = {
    id: uuid(),
    role: "buyer",
    name,
    email,
    phone,
    passwordHash: bcrypt.hashSync(password, 10),
    subscription: false,
    points: 0,
    totalFoodKg: 0,
    totalCo2Kg: 0,
    totalWaterL: 0,
    totalMoneySavedInr: 0,
    badges: [],
    createdAt: new Date().toISOString()
  };
  db.insert("users", user);
  const token = jwt.sign({ id: user.id, role: "buyer" }, JWT_SECRET, { expiresIn: "7d" });
  const { passwordHash, ...safeUser } = user;
  res.status(201).json({ token, user: safeUser });
});

// POST /api/auth/login
router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.find("users", (u) => u.email === email);
  if (!user || !bcrypt.compareSync(password || "", user.passwordHash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  const token = jwt.sign({ id: user.id, role: "buyer" }, JWT_SECRET, { expiresIn: "7d" });
  const { passwordHash, ...safeUser } = user;
  res.json({ token, user: safeUser });
});

module.exports = router;
