const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");

const router = express.Router();

// POST /api/clubs — start a group buy on a listing (e.g. "20 biryanis at 60% off if 5 people join")
router.post("/", (req, res) => {
  const { listingId, minMembers = 5, creatorUserId, bonusDiscountPercent = 10 } = req.body;
  const listing = db.find("listings", (l) => l.id === listingId);
  if (!listing) return res.status(404).json({ error: "Listing not found" });

  const club = {
    id: uuid(),
    listingId,
    sellerName: listing.sellerName,
    title: listing.title,
    minMembers: Number(minMembers),
    bonusDiscountPercent: Number(bonusDiscountPercent),
    members: creatorUserId ? [creatorUserId] : [],
    status: "open", // open -> unlocked -> expired
    createdAt: new Date().toISOString()
  };
  db.insert("clubs", club);
  res.status(201).json(club);
});

// POST /api/clubs/:id/join
router.post("/:id/join", (req, res) => {
  const { userId } = req.body;
  const club = db.find("clubs", (c) => c.id === req.params.id);
  if (!club) return res.status(404).json({ error: "Club not found" });
  if (club.status !== "open") return res.status(400).json({ error: "This club is no longer accepting members" });

  const members = Array.from(new Set([...club.members, userId]));
  const unlocked = members.length >= club.minMembers;
  const updated = db.update("clubs", club.id, {
    members,
    status: unlocked ? "unlocked" : "open"
  });

  if (unlocked) {
    // Apply the bonus discount on top of the listing's current discount, still capped at 90%
    const listing = db.find("listings", (l) => l.id === club.listingId);
    if (listing) {
      const boosted = Math.min(90, listing.discountPercent + club.bonusDiscountPercent);
      db.update("listings", listing.id, { discountPercent: boosted });
    }
  }

  res.json(updated);
});

router.get("/:id", (req, res) => {
  const club = db.find("clubs", (c) => c.id === req.params.id);
  if (!club) return res.status(404).json({ error: "Club not found" });
  res.json(club);
});

router.get("/", (req, res) => {
  res.json(db.all("clubs").sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
});

module.exports = router;
