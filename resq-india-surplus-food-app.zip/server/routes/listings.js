const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");
const { enforceMinDiscount, MIN_DISCOUNT_PERCENT } = require("../utils/validators");
const { suggestDiscount, suggestRecipes } = require("../utils/aiEngine");

const router = express.Router();

function hoursUntil(iso) {
  const diffMs = new Date(iso).getTime() - Date.now();
  return diffMs / (1000 * 60 * 60);
}

// Recompute a listing's live state (bakery auto-discount, flash sale, expiry) on every read
function withLiveState(listing) {
  const hrsLeft = hoursUntil(listing.pickupBy);
  let discountPercent = listing.discountPercent;
  let flashSale = listing.flashSale;

  // Real-time bakery deals: items baked more than `bakeryFreshHours` ago auto-discount further
  if (listing.category === "bakery" && listing.bakedAt) {
    const hrsSinceBaked = (Date.now() - new Date(listing.bakedAt).getTime()) / 3600000;
    if (hrsSinceBaked >= (listing.bakeryFreshHours || 4)) {
      discountPercent = Math.max(discountPercent, 70);
    }
  }

  // Neighborhood flash sale: auto-trigger + boost discount inside the last 30 minutes
  if (hrsLeft <= 0.5 && hrsLeft > 0) {
    flashSale = true;
    discountPercent = Math.max(discountPercent, 75);
  }

  discountPercent = enforceMinDiscount(discountPercent);
  const finalPrice = +(listing.originalPrice * (1 - discountPercent / 100)).toFixed(2);
  const expired = hrsLeft <= 0;

  return { ...listing, discountPercent, finalPrice, flashSale, hoursLeft: +hrsLeft.toFixed(2), expired };
}

// GET /api/listings  — browse, with filters
router.get("/", (req, res) => {
  const { category, shopType, flashSale, city, maxMinutesLeft, sellerId } = req.query;
  let listings = db.all("listings").map(withLiveState).filter((l) => !l.expired && l.quantityRemaining > 0);

  if (category) listings = listings.filter((l) => l.category === category);
  if (shopType) listings = listings.filter((l) => l.shopType === shopType);
  if (sellerId) listings = listings.filter((l) => l.sellerId === sellerId);
  if (flashSale === "true") listings = listings.filter((l) => l.flashSale);
  if (city) listings = listings.filter((l) => (l.city || "").toLowerCase() === city.toLowerCase());
  if (maxMinutesLeft) listings = listings.filter((l) => l.hoursLeft * 60 <= Number(maxMinutesLeft));

  // Sort soonest-expiring first — surfaces the most urgent rescues, per "AI Near Me in 15 min" idea
  listings.sort((a, b) => a.hoursLeft - b.hoursLeft);
  res.json(listings);
});

router.get("/:id", (req, res) => {
  const listing = db.find("listings", (l) => l.id === req.params.id);
  if (!listing) return res.status(404).json({ error: "Listing not found" });
  const live = withLiveState(listing);
  res.json({ ...live, recipeSuggestions: suggestRecipes(live.category) });
});

// POST /api/listings — seller creates a surplus listing. Enforces the platform-wide 50% discount floor.
router.post("/", (req, res) => {
  const {
    sellerId, title, description, category, shopType, originalPrice, discountPercent,
    quantityTotal, unit, weightKgPerUnit, pickupBy, city, isFamilyPack, isMysteryBox,
    bakedAt, bakeryFreshHours
  } = req.body;

  const seller = db.find("sellers", (s) => s.id === sellerId);
  if (!seller) return res.status(404).json({ error: "Seller not found" });
  if (!seller.verified) {
    return res.status(403).json({ error: "Seller not yet verified. Listings can only be created after FSSAI license verification." });
  }
  if (!title || !category || !originalPrice || !quantityTotal || !pickupBy) {
    return res.status(400).json({ error: "Missing required fields: title, category, originalPrice, quantityTotal, pickupBy" });
  }

  const finalDiscount = enforceMinDiscount(discountPercent);
  if (Number(discountPercent) < MIN_DISCOUNT_PERCENT) {
    // We don't hard-reject — we auto-correct up to the floor, but tell the seller why.
  }

  const listing = {
    id: uuid(),
    sellerId,
    sellerName: seller.businessName,
    shopType: shopType || seller.shopType,
    title,
    description: description || "",
    category, // bread, vegetables, fruits, dairy, bakery, rice, sweets, meal, buffet, other
    originalPrice: Number(originalPrice),
    discountPercent: finalDiscount,
    quantityTotal: Number(quantityTotal),
    quantityRemaining: Number(quantityTotal),
    unit: unit || "unit", // 'kg' | 'unit' | 'box'
    weightKgPerUnit: Number(weightKgPerUnit) || 0.5,
    pickupBy, // ISO datetime
    city: city || seller.city,
    isFamilyPack: !!isFamilyPack,
    isMysteryBox: !!isMysteryBox,
    flashSale: false,
    bakedAt: bakedAt || null,
    bakeryFreshHours: bakeryFreshHours || 4,
    createdAt: new Date().toISOString()
  };
  db.insert("listings", listing);
  res.status(201).json(withLiveState(listing));
});

// GET /api/listings/:id/ai-price — AI Smart Pricing suggestion (seller-facing tool)
router.get("/:id/ai-price", (req, res) => {
  const listing = db.find("listings", (l) => l.id === req.params.id);
  if (!listing) return res.status(404).json({ error: "Listing not found" });
  const hrsLeft = Math.max(0, hoursUntil(listing.pickupBy));
  const demandScore = Math.min(1, (listing.views || 0) / 50 || 0.5);
  const isRaining = req.query.isRaining === "true";
  const suggestion = suggestDiscount({ hoursToExpiry: hrsLeft, demandScore, isRaining });
  res.json(suggestion);
});

router.patch("/:id", (req, res) => {
  const updated = db.update("listings", req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: "Listing not found" });
  res.json(withLiveState(updated));
});

module.exports = router;
