const express = require("express");
const db = require("../db");

const router = express.Router();

// POST /api/subscriptions/:userId  { activate: true|false }
router.post("/:userId", (req, res) => {
  const { activate = true } = req.body;
  const user = db.update("users", req.params.userId, { subscription: !!activate });
  if (!user) return res.status(404).json({ error: "User not found" });
  const { passwordHash, ...safeUser } = user;
  res.json({ user: safeUser, note: activate ? "Subscribed: extra 10% off every order + early access to flash sales" : "Subscription cancelled" });
});

module.exports = router;
