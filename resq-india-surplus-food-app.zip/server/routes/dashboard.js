const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/dashboard/user/:id — personal carbon savings dashboard
router.get("/user/:id", (req, res) => {
  const user = db.find("users", (u) => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  const orders = db.filter("orders", (o) => o.userId === req.params.id);

  const byMonth = {};
  orders.forEach((o) => {
    const month = o.createdAt.slice(0, 7); // YYYY-MM
    byMonth[month] = byMonth[month] || { foodKg: 0, co2Kg: 0, moneyInr: 0, orders: 0 };
    byMonth[month].foodKg += o.foodSavedKg;
    byMonth[month].co2Kg += o.co2SavedKg;
    byMonth[month].moneyInr += o.moneySavedInr;
    byMonth[month].orders += 1;
  });

  const { passwordHash, ...safeUser } = user;
  res.json({
    ...safeUser,
    ordersCount: orders.length,
    monthly: Object.entries(byMonth).map(([month, v]) => ({ month, ...v })),
    equivalents: {
      // fun, relatable comparisons for the dashboard UI
      treesEquivalent: +(user.totalCo2Kg / 21).toFixed(2), // ~21kg CO2 absorbed/tree/year
      carKmAvoided: +(user.totalCo2Kg / 0.12).toFixed(1)  // ~0.12kg CO2/km average car
    }
  });
});

// GET /api/dashboard/seller/:id — corporate/business dashboard
router.get("/seller/:id", (req, res) => {
  const seller = db.find("sellers", (s) => s.id === req.params.id);
  if (!seller) return res.status(404).json({ error: "Seller not found" });
  const orders = db.filter("orders", (o) => o.sellerId === req.params.id);
  const listings = db.filter("listings", (l) => l.sellerId === req.params.id);

  const productCounts = {};
  const hourCounts = {};
  orders.forEach((o) => {
    o.items.forEach((it) => {
      productCounts[it.title] = (productCounts[it.title] || 0) + it.qty;
    });
    const hr = new Date(o.createdAt).getHours();
    hourCounts[hr] = (hourCounts[hr] || 0) + 1;
  });
  const popularProducts = Object.entries(productCounts).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([title, qty]) => ({ title, qty }));
  const peakHours = Object.entries(hourCounts).sort((a, b) => b[1] - a[1]).slice(0, 3)
    .map(([hour, count]) => ({ hour: `${hour}:00`, count }));

  const { passwordHash, ...safeSeller } = seller;
  res.json({
    ...safeSeller,
    activeListings: listings.filter((l) => l.quantityRemaining > 0).length,
    popularProducts,
    peakHours
  });
});

// GET /api/dashboard/global — platform-wide live counters, used on the homepage board
router.get("/global", (req, res) => {
  const orders = db.all("orders");
  const today = new Date().toISOString().slice(0, 10);
  const todays = orders.filter((o) => o.createdAt.slice(0, 10) === today);
  const sum = (arr, key) => +arr.reduce((s, o) => s + (o[key] || 0), 0).toFixed(2);
  res.json({
    todayFoodKg: sum(todays, "foodSavedKg"),
    todayCo2Kg: sum(todays, "co2SavedKg"),
    todayMoneyInr: sum(todays, "moneySavedInr"),
    allTimeFoodKg: sum(orders, "foodSavedKg"),
    allTimeCo2Kg: sum(orders, "co2SavedKg"),
    allTimeMoneyInr: sum(orders, "moneySavedInr"),
    sellersCount: db.all("sellers").filter((s) => s.verified).length,
    ordersCount: orders.length
  });
});

// GET /api/dashboard/leaderboard — gamification leaderboard
router.get("/leaderboard", (req, res) => {
  const leaders = db.all("users")
    .sort((a, b) => b.points - a.points)
    .slice(0, 20)
    .map((u) => ({ name: u.name, points: u.points, totalFoodKg: u.totalFoodKg, badges: u.badges }));
  res.json(leaders);
});

module.exports = router;
