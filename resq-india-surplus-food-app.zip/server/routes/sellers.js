const express = require("express");
const bcrypt = require("bcryptjs");
const { v4: uuid } = require("uuid");
const db = require("../db");
const { isValidFssai, isValidGst, isValidEmail, isValidIndianPhone } = require("../utils/validators");
const { forecastDemand } = require("../utils/aiEngine");

const router = express.Router();

const SHOP_TYPES = ["restaurant", "supermarket", "bakery", "sweet_shop", "tiffin_service", "caterer", "grocery", "individual", "other"];

// POST /api/sellers/register
// A valid Indian FSSAI license number (14 digits) is REQUIRED to register as a seller.
router.post("/register", (req, res) => {
  const { businessName, ownerName, email, phone, password, shopType, fssaiLicense, gstNumber, address, city, lat, lng } = req.body;

  if (!businessName || !ownerName || !isValidEmail(email) || !isValidIndianPhone(phone) || !password) {
    return res.status(400).json({ error: "Missing/invalid business name, owner name, email, phone, or password" });
  }
  if (!SHOP_TYPES.includes(shopType)) {
    return res.status(400).json({ error: `shopType must be one of: ${SHOP_TYPES.join(", ")}` });
  }
  if (!isValidFssai(fssaiLicense)) {
    return res.status(400).json({
      error: "A valid 14-digit Indian FSSAI license number is mandatory to sell food on this platform.",
      help: "Find your FSSAI number on your license certificate or at foscos.fssai.gov.in"
    });
  }
  if (gstNumber && !isValidGst(gstNumber)) {
    return res.status(400).json({ error: "GST number format looks invalid (optional field, but must be valid if provided)" });
  }
  if (db.find("sellers", (s) => s.email === email)) {
    return res.status(409).json({ error: "Email already registered" });
  }
  if (db.find("sellers", (s) => s.fssaiLicense === fssaiLicense)) {
    return res.status(409).json({ error: "This FSSAI license number is already registered to another account" });
  }

  const seller = {
    id: uuid(),
    role: "seller",
    businessName,
    ownerName,
    email,
    phone,
    passwordHash: bcrypt.hashSync(password, 10),
    shopType,
    fssaiLicense,
    gstNumber: gstNumber || null,
    address: address || "",
    city: city || "",
    lat: lat || null,
    lng: lng || null,
    // Format is valid, but a human/automated compliance check against the real
    // FSSAI database (FoSCoS) should happen before `verified` flips to true.
    verified: false,
    verificationStatus: "pending_manual_review",
    subscriptionPlan: "free",
    featured: false,
    rating: 0,
    totalOrders: 0,
    totalFoodKgRescued: 0,
    totalMoneyRecoveredInr: 0,
    totalCo2SavedKg: 0,
    createdAt: new Date().toISOString()
  };
  db.insert("sellers", seller);
  const { passwordHash, ...safeSeller } = seller;
  res.status(201).json({ seller: safeSeller, note: "Registered. Verification pending — you can add listings once verified by our team (usually within 24h)." });
});

// POST /api/sellers/login
router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const seller = db.find("sellers", (s) => s.email === email);
  if (!seller || !bcrypt.compareSync(password || "", seller.passwordHash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  const { passwordHash, ...safeSeller } = seller;
  res.json({ seller: safeSeller });
});

// Admin-style manual verification (in production: gated behind an admin role)
router.post("/:id/verify", (req, res) => {
  const seller = db.update("sellers", req.params.id, { verified: true, verificationStatus: "verified" });
  if (!seller) return res.status(404).json({ error: "Seller not found" });
  const { passwordHash, ...safeSeller } = seller;
  res.json({ seller: safeSeller });
});

router.get("/:id", (req, res) => {
  const seller = db.find("sellers", (s) => s.id === req.params.id);
  if (!seller) return res.status(404).json({ error: "Seller not found" });
  const { passwordHash, ...safeSeller } = seller;
  res.json(safeSeller);
});

router.get("/", (req, res) => {
  const sellers = db.all("sellers").map(({ passwordHash, ...s }) => s);
  res.json(sellers);
});

// AI demand forecast for a shop, based on its past daily order counts
router.get("/:id/forecast", (req, res) => {
  const orders = db.filter("orders", (o) => o.sellerId === req.params.id);
  const byDay = {};
  orders.forEach((o) => {
    const day = o.createdAt.slice(0, 10);
    byDay[day] = (byDay[day] || 0) + o.items.reduce((s, i) => s + i.qty, 0);
  });
  const series = Object.values(byDay);
  res.json(forecastDemand(series));
});

module.exports = router;
