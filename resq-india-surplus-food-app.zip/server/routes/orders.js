const express = require("express");
const { v4: uuid } = require("uuid");
const db = require("../db");
const { computeImpact, badgesForTotal } = require("../utils/aiEngine");

const router = express.Router();

// POST /api/orders
// body: { userId, items: [{listingId, qty}], donationInr, fulfillment: 'pickup'|'delivery', clubId? }
router.post("/", (req, res) => {
  const { userId, items, donationInr = 0, fulfillment = "pickup" } = req.body;
  const user = db.find("users", (u) => u.id === userId);
  if (!user) return res.status(404).json({ error: "User not found" });
  if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: "Cart is empty" });

  let subtotal = 0;
  let originalTotal = 0;
  let foodKg = 0;
  const orderItems = [];
  let sellerId = null;

  for (const item of items) {
    const listing = db.find("listings", (l) => l.id === item.listingId);
    if (!listing) return res.status(404).json({ error: `Listing ${item.listingId} not found` });
    if (item.qty > listing.quantityRemaining) {
      return res.status(409).json({ error: `Only ${listing.quantityRemaining} left of "${listing.title}"` });
    }
    sellerId = sellerId || listing.sellerId;
    if (sellerId !== listing.sellerId) {
      return res.status(400).json({ error: "A custom box can only contain items from one seller per order (pick up in one trip)" });
    }
    const lineFinalPrice = +(listing.originalPrice * (1 - listing.discountPercent / 100) * item.qty).toFixed(2);
    const lineOriginalPrice = +(listing.originalPrice * item.qty).toFixed(2);
    subtotal += lineFinalPrice;
    originalTotal += lineOriginalPrice;
    foodKg += (listing.weightKgPerUnit || 0.5) * item.qty;

    orderItems.push({
      listingId: listing.id,
      title: listing.title,
      qty: item.qty,
      unitFinalPrice: +(listing.originalPrice * (1 - listing.discountPercent / 100)).toFixed(2),
      discountPercent: listing.discountPercent
    });

    db.update("listings", listing.id, { quantityRemaining: listing.quantityRemaining - item.qty });
  }

  // Subscription members get an extra 10% off the already-discounted subtotal
  const subscriptionDiscount = user.subscription ? +(subtotal * 0.1).toFixed(2) : 0;
  const total = +(subtotal - subscriptionDiscount + Number(donationInr || 0)).toFixed(2);
  const moneySaved = +(originalTotal - subtotal).toFixed(2);

  const impact = computeImpact(foodKg);

  const order = {
    id: uuid(),
    userId,
    sellerId,
    items: orderItems,
    fulfillment,
    subtotal: +subtotal.toFixed(2),
    subscriptionDiscount,
    donationInr: Number(donationInr || 0),
    total,
    originalTotal: +originalTotal.toFixed(2),
    moneySavedInr: moneySaved,
    foodSavedKg: impact.foodKg,
    co2SavedKg: impact.co2SavedKg,
    waterSavedL: impact.waterSavedL,
    pointsEarned: impact.points,
    status: "confirmed",
    createdAt: new Date().toISOString()
  };
  db.insert("orders", order);

  // Update buyer stats + badges
  const newTotalKg = user.totalFoodKg + impact.foodKg;
  const updatedUser = db.update("users", userId, {
    points: user.points + impact.points,
    totalFoodKg: +newTotalKg.toFixed(2),
    totalCo2Kg: +(user.totalCo2Kg + impact.co2SavedKg).toFixed(2),
    totalWaterL: user.totalWaterL + impact.waterSavedL,
    totalMoneySavedInr: +(user.totalMoneySavedInr + moneySaved).toFixed(2),
    badges: badgesForTotal(newTotalKg)
  });

  // Update seller (corporate dashboard) stats
  const seller = db.find("sellers", (s) => s.id === sellerId);
  if (seller) {
    db.update("sellers", sellerId, {
      totalOrders: seller.totalOrders + 1,
      totalFoodKgRescued: +(seller.totalFoodKgRescued + impact.foodKg).toFixed(2),
      totalMoneyRecoveredInr: +(seller.totalMoneyRecoveredInr + subtotal).toFixed(2),
      totalCo2SavedKg: +(seller.totalCo2SavedKg + impact.co2SavedKg).toFixed(2)
    });
  }

  const { passwordHash, ...safeUser } = updatedUser;
  res.status(201).json({ order, impact, user: safeUser });
});

router.get("/user/:userId", (req, res) => {
  const orders = db.filter("orders", (o) => o.userId === req.params.userId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(orders);
});

router.get("/seller/:sellerId", (req, res) => {
  const orders = db.filter("orders", (o) => o.sellerId === req.params.sellerId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(orders);
});

module.exports = router;
