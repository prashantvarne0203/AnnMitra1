require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

const authRoutes = require("./routes/auth");
const sellerRoutes = require("./routes/sellers");
const listingRoutes = require("./routes/listings");
const orderRoutes = require("./routes/orders");
const dashboardRoutes = require("./routes/dashboard");
const clubRoutes = require("./routes/clubs");
const subscriptionRoutes = require("./routes/subscriptions");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/sellers", sellerRoutes);
app.use("/api/listings", listingRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/clubs", clubRoutes);
app.use("/api/subscriptions", subscriptionRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true, service: "ResQ India API" }));

// Serve the static frontend
app.use(express.static(path.join(__dirname, "..", "public")));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

// Basic error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server" });
});

app.listen(PORT, () => {
  console.log(`ResQ India server running at http://localhost:${PORT}`);
});
