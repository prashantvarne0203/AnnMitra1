// server/utils/validators.js

// FSSAI (Food Safety and Standards Authority of India) license numbers are
// 14-digit numeric codes. This is a format check only — in production this
// must be verified against the real FSSAI database via their API/portal,
// which is flagged clearly in README.md as a required integration.
function isValidFssai(license) {
  return /^\d{14}$/.test(String(license || "").trim());
}

// GST number format (optional, extra business proof): 15 chars, alnum pattern.
function isValidGst(gst) {
  return /^\d{2}[A-Z]{5}\d{4}[A-Z]{1}\d[Z]{1}[A-Z\d]{1}$/.test(String(gst || "").trim().toUpperCase());
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || "").trim());
}

function isValidIndianPhone(phone) {
  return /^[6-9]\d{9}$/.test(String(phone || "").trim());
}

const MIN_DISCOUNT_PERCENT = 50;

function enforceMinDiscount(discountPercent) {
  const d = Number(discountPercent);
  if (Number.isNaN(d)) return MIN_DISCOUNT_PERCENT;
  return Math.max(MIN_DISCOUNT_PERCENT, Math.min(90, d));
}

module.exports = {
  isValidFssai,
  isValidGst,
  isValidEmail,
  isValidIndianPhone,
  MIN_DISCOUNT_PERCENT,
  enforceMinDiscount
};
