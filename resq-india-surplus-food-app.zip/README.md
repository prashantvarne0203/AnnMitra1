# ResQ India — Surplus Food Rescue Marketplace (MVP)

A working full-stack prototype of a surplus-food marketplace for the Indian market: consumers buy surplus
food from restaurants, bakeries, supermarkets, and other food shops at **a minimum 50% discount**, sellers
must register with a **valid Indian FSSAI food license**, and every order returns an **AI-calculated
food/water/CO₂ savings receipt**.

This is a buildable, runnable MVP, not the full 30-feature vision described in the brief — see
"What's implemented vs. roadmap" below for an honest map of which ideas are working code today.

## Quick start

```bash
npm install
node server/seed.js   # loads demo sellers + listings + a demo buyer account
npm start              # runs at http://localhost:4000
```

Open `http://localhost:4000` in a browser. Demo buyer login: `demo@resq.in` / `password123`.

No database server or native build tools are required — data is stored in a local JSON file at
`server/data/store.json` (see "Swapping in a real database" below).

## Architecture

```
server/
  index.js        Express app entry, mounts all routes, serves the frontend
  db.js            Tiny JSON-file datastore (swap for Postgres/Mongo in production)
  seed.js          Demo data generator
  utils/
    aiEngine.js    Rule-based "AI": smart pricing, savings/carbon calc, recipes, demand forecast, badges
    validators.js  FSSAI/GST/phone/email format checks + the 50% discount floor
  routes/
    auth.js         Buyer signup/login (bcrypt + JWT)
    sellers.js       Seller registration (FSSAI-gated), verification, per-seller demand forecast
    listings.js      Browse/create/update surplus listings, live discount/flash-sale state, AI pricing
    orders.js        Custom-box checkout, impact calculation, points/badges, seller stats update
    dashboard.js     Buyer carbon dashboard, seller/corporate dashboard, leaderboard, global counters
    clubs.js         Neighborhood Rescue Clubs (group-buy unlock)
    subscriptions.js Premium membership toggle (extra 10% off)
public/
  index.html, css/style.css, js/app.js   Single-page vanilla JS frontend (no build step)
```

Everything is plain Node/Express + vanilla JS/HTML/CSS on purpose — it runs with just `npm install`,
no bundler, no native compiled dependencies, no external database to provision.

## What's implemented vs. roadmap

**Core requirements from the brief — implemented:**
- Consumers can browse and order surplus food from restaurants, supermarkets, bakeries, and other shops, for **pickup**.
- Sellers must register with a valid-format **Indian FSSAI license number (14 digits)**; listings are blocked until an account is marked `verified`.
- **Minimum 50% discount enforced server-side** on every listing (`enforceMinDiscount` in `validators.js`) — a seller cannot publish anything below the floor.
- **AI savings calculation after checkout**: kg of food rescued, % vs. original, CO₂ kg avoided, litres of water avoided, using transparent fixed factors (see `aiEngine.js`).

**Unique ideas from the brief — implemented:**
1. AI Smart Pricing (rule-based, factors in hours-to-expiry, demand, weather, time of day) — `GET /api/listings/:id/ai-price`
2. Custom food boxes (build-your-own box from any seller's live listings)
3. Real-time bakery deals (auto-discount after a configurable "hours since baked" threshold)
4. Neighborhood flash sales (auto-triggers extra discount inside the last 30 minutes)
5. Subscription plans (extra 10% off toggle)
6. Family meal packs (flag on listings)
7. Gamification (points per kg, badge tiers, leaderboard)
9. Carbon savings dashboard (kg/CO₂/water/money, trees & car-km equivalents, monthly history)
10. Donation add-on at checkout
11. Recipe suggestions (rule-based, by food category)
12. Last-minute buffet deals (category + countdown)
13. Corporate/seller dashboard (waste reduced, money recovered, CO₂ saved, popular products, peak hours)
14. AI demand forecasting for shops (simple moving-average heuristic) — `GET /api/sellers/:id/forecast`
15. Pickup vs. delivery flag on orders
18. Mystery premium boxes (flag on listings)
"₹99/₹199/₹299 fixed-price rescue box" — modeled as a normal listing with a fixed final price
Neighborhood Rescue Clubs (group-buy unlock: 5+ members unlocks a bonus discount)

**Explicitly out of scope for this MVP (roadmap, needs real infra/partnerships):**
- Real FSSAI database verification via FoSCoS (today: format check + manual-review flag only — flagged clearly in the API response)
- WhatsApp ordering/notifications (needs WhatsApp Business API credentials)
- Live courier/delivery dispatch, real payments/UPI integration
- Real geolocation-based "near me" radius search (city-name filter only today)
- Real AI/ML pricing model (today: transparent, explainable rule-based heuristic — swap-in ready)
- Event/wedding leftover marketplace, florists, pharmacies, cosmetics ("Everything Rescue Marketplace" expansion)
- Admin moderation console, real payment gateway, image uploads for listings

## Revenue model (as designed, hooks present in the data model)

Commission is computed implicitly today (`subtotal` per order is what a seller receives; a `commission_rate`
field is the natural next addition to `orders.js`). `subscriptionPlan` and `featured` fields already exist on
sellers for business subscriptions and featured listings; `subscription` on buyers is wired to a real 10% discount.

## Security & production notes

This is a demo-quality auth implementation (JWT with a dev secret, no rate limiting, no HTTPS enforcement,
no email/phone OTP verification, no payment gateway). Before any real launch:
- Move `JWT_SECRET` to a real secret manager, never commit it
- Add OTP-based phone/email verification for both buyers and sellers
- Integrate FoSCoS/FSSAI's real verification API instead of a format check
- Add a payment gateway (Razorpay/UPI) instead of the current "confirm on click" checkout
- Add rate limiting, input sanitization audits, and HTTPS
- Replace the JSON-file datastore with PostgreSQL/MongoDB for concurrent-write safety

## Swapping in a real database

Every route only calls the functions exported by `server/db.js` (`all`, `find`, `filter`, `insert`, `update`,
`remove`). To move to Postgres/Mongo, reimplement those five functions against the real database — no route
file needs to change.

## Environmental impact assumptions

`server/utils/aiEngine.js` uses fixed, commonly-cited estimates for a transparent demo calculation:
- 2.5 kg CO₂e avoided per kg of food rescued
- 1000 L of virtual water avoided per kg of food rescued

Replace these with India/category-specific factors (rice vs. dairy vs. bakery have very different footprints)
when real data is available — they're isolated constants at the top of the file.
